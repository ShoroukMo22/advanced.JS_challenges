const inputElement = document.querySelector("#input");
const buttonElement = document.querySelector("#button");

buttonElement?.addEventListener('click', async(event) => {
    event.preventDefault();
    const userName = inputElement.value;
    try{
        const result = await fetchData(userName);
    fetchData(userName).then(console.log)
    fillData('img', result.avatar_url, true)
    fillData('name',  result.name)
    fillData('bio',result.bio)
    fillData('twitter_username', result.twitter_username)
    fillData('followers', result.followers)
    console.log(result)
    } catch(err){
        alert(err);
    }
    
});

async function fetchData(userName){
   const result = await fetch(`https://api.github.com/users/${userName}`);
  if(result.ok){
    return result.json();
  }
  return Promise.reject(new Error ('this username is not found'))
 // throw new Error(404)
}


const fillData = (id, data, isImg) => {
    if (!isImg ) {
        const element = document.querySelector(`#${id}`);
        element.textContent=data;
    } else {
        const element = document.querySelector(`#${id}`);
        element.src = data
    }
    }
