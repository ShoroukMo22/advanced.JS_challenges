/*two types to implement OOP in JS language */

/*1: prototypal function */

// function Laptop (brand, model, batteryPercentage = 100) {
//     this.brand = brand;
//     this.model = model;
//     this.batteryPercentage = batteryPercentage;


// }

// Laptop.prototype.useSoftware = function(batteryPercentage) {
//     this.batteryPercentage -= 15
//     if(this.batteryPercentage<0){
//         this.batteryPercentage = 0;
//     }
//     console.log( this.batteryPercentage+"%");
// }


// Laptop.prototype.charge = function(batteryPercentage) {
//      this.batteryPercentage += 25
//     if(this.batteryPercentage>100){
//         this.batteryPercentage = 100;
//     }
//     console.log( this.batteryPercentage+"%");
// };

// const laptop1 = new Laptop("dell", "g15")

// console.log(laptop1.useSoftware());
// console.log(laptop1.charge());


// const laptop2 = new Laptop("hp", "h23", 70)

// console.log(laptop2.useSoftware());
// console.log(laptop2.charge());

/*2:ES6 classes */

class Laptop{
    constructor(brand, model, batteryPercentage = 100) {
        this.brand = brand;
        this.model = model;
        this.batteryPercentage = batteryPercentage;
    
    
    }

    useSoftware (batteryPercentage) {
        this.batteryPercentage -= 15
        if(this.batteryPercentage<0){
            this.batteryPercentage = 0;
        }
        console.log( this.batteryPercentage+"%");
    }
    
    
    charge(batteryPercentage) {
         this.batteryPercentage += 25
        if(this.batteryPercentage>100){
            this.batteryPercentage = 100;
        }
        console.log( this.batteryPercentage+"%");
    };
    

}

const laptop1 = new Laptop("dell", "g15")
    
    console.log(laptop1.useSoftware());
    console.log(laptop1.charge());
    
    
    const laptop2 = new Laptop("hp", "h23", 50)
    
    console.log(laptop2.useSoftware());
    console.log(laptop2.charge());



    /*test question */

//     var obj = {};
// console.log(obj.toString());
 